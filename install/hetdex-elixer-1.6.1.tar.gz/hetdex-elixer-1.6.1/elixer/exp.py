import fiber as ifu_fiber
import ifu
import hetdex_fits
import spectrum
import numpy as np
import global_config as G
import scipy



import matplotlib.pyplot as plt



#253	253	5.0	214.92583	52.57462	4123.23	22.87	-12.48	8.8	666	1.0	1337.4	3.41040263256e-16	41.81	1.06616520164e-17	31.987562784	0.0720314342493	5
# 20170603T064844.9_051_105_051_LL_109	20170603	2	2	116	214.92598	52.57449	16.4	9.06594194335	317	994
# 20170603T064157.9_051_105_051_LL_108	20170603	2	1	117	214.9256	52.57482	11.1	7.99870678375	317	985
# 20170603T064844.9_051_105_051_LL_089	20170603	2	2	136	214.92589	52.57519	9.9	5.10692441614	318	820
# 20170603T065529.2_051_105_051_LL_109	20170603	2	3	116	214.92627	52.57486	8.8	6.91324401369	317	994
# 20170603T064157.9_051_105_051_LL_089	20170603	2	1	136	214.92654	52.57523	7.6	1.6941157368	318	820


#i = ifu.IFU("20171026T055608.2_306_043_057_RU_041")
if False:
    i = ifu.IFU("20170603T064844.9_051_105_051_LL_109")

    i.build_from_files() #expid=2)
    i.build_fibers()
    s = spectrum.Spectrum()


    fiber_idx = i.get_absolute_fiber_index("LL",109)
    cw=4123.23
   # cw=5350.0

    x = i.exposure(2).fibers[i.get_absolute_fiber_index("LL",109)].interp_spectra_wavelengths

    v  = i.exposure(2).fibers[i.get_absolute_fiber_index("LL",109)].interp_spectra_counts
    v += i.exposure(1).fibers[i.get_absolute_fiber_index("LL",108)].interp_spectra_counts
    v += i.exposure(2).fibers[i.get_absolute_fiber_index("LL",89)].interp_spectra_counts
    v += i.exposure(3).fibers[i.get_absolute_fiber_index("LL",109)].interp_spectra_counts
    v += i.exposure(1).fibers[i.get_absolute_fiber_index("LL",89)].interp_spectra_counts

    v = v/5.0

    s.build_full_width_spectrum(x,v,None, central_wavelength=cw,show_skylines=True,show_peaks=True,
                                name="testspec1",dw=5,h=30,dh=5,zero=0.0)

    print(spectrum.est_snr(x,v,cw,40,5))
    print(spectrum.signal_score(x,v,cw))

    sols = s.classify(x, v, cw)
    s.build_full_width_spectrum(show_skylines=True, show_peaks=True, name="testsol1")

###############
#240	240	5.0	214.92604	52.57537	5378.4	24.15	-10.29	6.4	666	1.0	508.9	9.3383363738e-17	15.03	2.7580113126e-18	33.8589487691	0.284801251776	5
# 20170603T065529.2_051_105_051_LL_089	20170603	2	3	136	214.92616	52.57556	6.4	5.4	955	818
# 20170603T064844.9_051_105_051_LL_089	20170603	2	2	136	214.92589	52.57519	6.2	5.2	955	818
# 20170603T065529.2_051_105_051_LL_109	20170603	2	3	116	214.92627	52.57486	5.1	3.02202414323	954	994
# 20170603T064844.9_051_105_051_LL_090	20170603	2	2	135	214.92694	52.57489	2.8	0.0	955	827
# 20170603T064844.9_051_105_051_LL_070	20170603	2	2	155	214.92683	52.5756	2.6	0.0	957	643

if False:
    i = ifu.IFU("20170603T065529.2_051_105_051_LL_089")
    i.build_from_files()
    i.build_fibers()
    s = spectrum.Spectrum()

    cw=5378.4

    x = i.exposure(3).fibers[i.get_absolute_fiber_index("LL",89)].interp_spectra_wavelengths

    v  = i.exposure(3).fibers[i.get_absolute_fiber_index("LL",89)].interp_spectra_counts
    v += i.exposure(2).fibers[i.get_absolute_fiber_index("LL",89)].interp_spectra_counts
    v += i.exposure(3).fibers[i.get_absolute_fiber_index("LL",109)].interp_spectra_counts
    v += i.exposure(2).fibers[i.get_absolute_fiber_index("LL",90)].interp_spectra_counts
    v += i.exposure(2).fibers[i.get_absolute_fiber_index("LL",70)].interp_spectra_counts
    v = v/5.0
    s.build_full_width_spectrum(x,v,None, central_wavelength=cw,show_skylines=True,show_peaks=True,
                               name="testspec2",dw=5,h=25,dh=5,zero=0.0)

    print(spectrum.est_snr(x,v,cw,40,5))
    print(spectrum.signal_score(x, v, cw))

    sols = s.classify(x,v,cw)
    s.build_full_width_spectrum(show_skylines=True,show_peaks=True,name="testsol2")


if False:
    i = ifu.IFU("20170603T065529.2_051_105_051_LL_089")
    i.build_from_files()
    i.build_fibers()
    x,v,cw = i.sum_fibers_from_elixer("240	240	5.0	214.92604	52.57537	5378.4	24.15	-10.29	6.4	666	1.0	508.9	9.3383363738e-17	15.03	2.7580113126e-18	33.8589487691	0.284801251776	5	20170603T065529.2_051_105_051_LL_089	20170603	2	3	136	214.92616	52.57556	6.4	5.4	955	818	20170603T064844.9_051_105_051_LL_089	20170603	2	2	136	214.92589	52.57519	6.2	5.2	955	818	20170603T065529.2_051_105_051_LL_109	20170603	2	3	116	214.92627	52.57486	5.1	3.02202414323	954	994	20170603T064844.9_051_105_051_LL_090	20170603	2	2	135	214.92694	52.57489	2.8	0.0	955	827	20170603T064844.9_051_105_051_LL_070	20170603	2	2	155	214.92683	52.5756	2.6	0.0	957	643")

    s = spectrum.Spectrum()
    s.build_full_width_spectrum(x,v,None, central_wavelength=cw, show_skylines=True, show_peaks=True,
                                name="testspec3", dw=5, h=25, dh=5, zero=0.0)

    print(spectrum.est_snr(x, v, cw, 40, 5))
    print(spectrum.signal_score(x, v, cw))

    sols = s.classify(x, v, cw)
    s.build_full_width_spectrum(show_skylines=True, show_peaks=True, name="testsol3")


if False: #example of slot 103, id 198 ... needs more lines ... have obvious line w/o counterpart
    #i = ifu.IFU("20170603T065529.2_051_105_051_LL_089")
    #i = ifu.IFU("20170603T065529.2",ifuslot=105)
    i = ifu.IFU("20170603T065529.2", ifuslot=103)

    #i.build_from_files()
    #i.build_fibers()
    path = "/work/03261/polonius/maverick/share/hetdex/detects/runs/vol_20170603v02/vol_20170603v02/"
    file = path + "vol_20170603v02_fib.txt"

    x, v, cw = i.sum_fibers_from_fib_file(file,198)



    #cw = 4651.0

    s = spectrum.Spectrum()
    cw = s.find_central_wavelength(x, v, None)
    s.build_full_width_spectrum(x,v,None, central_wavelength=cw, show_skylines=True, show_peaks=True,
                                name="testspec", dw=5, h=25, dh=5, zero=0.0)

    #print(spectrum.est_snr(x, v, cw, 40, 5))
    #full spectrum with all posibilities
    #print(spectrum.signal_score(x, v, cw))

    sols = s.classify(x, v, cw)
    s.build_full_width_spectrum(show_skylines=True, show_peaks=True, name="testsol")
    if len(sols) == 0:
        print ("No solutions")
    else:
        if sols[0].score < 3.0:
            print("Weak solution")
        if len(sols) > 1:
            if sols[0].frac_score / sols[1].frac_score < 1.5:
                print("No clear solution")



if False:


    # i = ifu.IFU("20170603T065529.2_051_105_051_LL_089")
    # i = ifu.IFU("20170603T065529.2",ifuslot=105)
   # i = ifu.IFU("20170603T065529.2", ifuslot=103)
    i = ifu.IFU("20171015v004", ifuslot=105)

    # i.build_from_files()
    # i.build_fibers()
    path = "/work/03261/polonius/maverick/karl_vol/20171015v004/20171015v004/"
    file = path + "20171015v004_fib.txt"

    x, v, cw = i.sum_fibers_from_fib_file(file, line_id=91)#line_id=107)
    #print(cw)
    #print("SNR(old)", spectrum.est_snr(x, v, cw))  # , 40, 5))

    spectrum.signal_score(wavelengths=x, values=v, errors=None, central=cw, sbr=None, show_plot=True)

    if x is not None:
       # cw = 0 # test to see if can recover cw
        s = spectrum.Spectrum()
        #cw = s.find_central_wavelength(x,v)
        #print (cw)
        #s.build_full_width_spectrum(x,v,None, central_wavelength=cw, show_skylines=True, show_peaks=True,
        #                            name="testspec", dw=5, h=15, dh=5, zero=0.0)


        #print("SNR (5180)", spectrum.est_snr(x, v, 5180.0))#, 40, 5))




        # full spectrum with all posibilities
        # print(spectrum.signal_score(x, v, cw))

        sols = s.classify(x, v, None,cw)

        print("Flux",s.estflux)
        print("Cont",s.central_eli.cont)
        print("EW_obs",s.eqw_obs)
        print("SNR",s.central_eli.snr)
        print("P_LAE",s.p_lae)
        print("P_OII",s.p_oii)
        print("P_LAE/P_OII", s.p_lae_oii_ratio)

        s.build_full_width_spectrum(show_skylines=True, show_peaks=True, name="testsol")
        if len(sols) == 0:
            print ("No solutions")
        else:
            if sols[0].score < 3.0:
                print("Weak solution")
            if len(sols) > 1:
                if sols[0].frac_score / sols[1].frac_score < 1.5:
                    print("No clear solution")

        #full w/o solution
        s.build_full_width_spectrum(x,v,None,central_wavelength=cw, show_skylines=True, show_peaks=True,
                                name="testspec", dw=5, h=15, dh=5, zero=0.0)

    else:
        print("Error summing fibers")


def plot_bob(penalty_cutoff,x,v,bob_M,bob_wo,bob_emis,s,name=None):

    plt.figure(figsize=(20,5))
    out = np.correlate(v, bob_M, mode='same')
    plt.hlines(penalty_cutoff,3500,5500,colors='r')
    plt.plot(x,out/1000,label="corr")
    plt.plot(x,v, label ="spec")
    plt.plot(x,bob_M, label="tophat")
    plt.ylim(ymin=-100)

    #make labels
    z = bob_wo / bob_emis.w_rest - 1.0
    for emis in s.emission_lines:
        w_obs = emis.redshift(z)
        if (w_obs > x[0]) and (w_obs < x[-1]):
            plt.text(w_obs, -10, " {" + emis.name, rotation=-90, ha='center', va='top',
                          fontsize=12)  # use the e color for this family

    plt.legend()
    if name is None:
        plt.show()
    else:
        plt.savefig(name)


def plot_corr(plt,title,x,v,filter,pause=0.001):
    return
    #plt.figure(figsize=(20,5))
    plt.clf()
    out = np.correlate(v,filter*v, mode='same')
    plt.title(title)
    plt.plot(x,out)
    plt.plot(x,v)
    plt.plot(x,filter*v)
    plt.ylim(ymax=6000)
   # plt.ion()
    plt.pause(pause)
    plt.show(block=False)

from scipy.stats import skew, kurtosis
from scipy.optimize import curve_fit

def gaussian(x,x0,sigma,a=1.0):
    if (x is None) or (x0 is None) or (sigma is None):
        return None

    return a*np.exp(-np.power((x - x0)/sigma, 2.)/2.)

def noise_hist(ifu,exp,fib,bins=100):
    v = ifu.exposure(exp).fibers[fib].interp_spectra_counts
    for idx in range(len(v) - 1):
        d[idx] = (v[idx + 1] - v[idx])



    plt.figure()
    n,b,p = plt.hist(d,bins=bins) #n = count in the bin, b = bin (left edges) and last right edge

    # todo: fit a gaussian and show parameters
    x = np.zeros(len(n))
    for i in range(len(b)-1):
        x[i] = 0.5*(b[i]+b[i+1])

    parm, pcov = curve_fit(gaussian, np.float64(x), np.float64(n), p0=(0.0,1.0, 0.0))
    fit_wave = gaussian(x, parm[0], parm[1], parm[2])

    plt.title("x0 = %g, sigma= %g" %(parm[0],parm[1]))

    plt.plot(x,fit_wave)

    plt.show(block=True)
    plt.close()

#Isak
if True:
    #turn back on screen plotting
    plt.switch_backend('QT4Agg')
    #
    datestr = "20170529v09"
    i = ifu.IFU(datestr, ifuslot=94)
    path = "/work/03261/polonius/maverick/karl_det/vol/" + datestr + "/"
    file = path + datestr + "_fib.txt"
    x, v, e, cw = i.sum_fibers_from_fib_file(file, line_id=18)  # ,fiber_indicies=[0])#line_id=107)


    #
    # datestr = "20180415v16"
    # i = ifu.IFU(datestr, ifuslot=104)
    # file = "/work/03261/polonius/maverick/share/hetdex/detects/runs/gn2/gn2/gn2_fib.txt"
    # #line_id == Entry ID (should be [OII]
    # x, v, e, cw = i.sum_fibers_from_fib_file(file, line_id=430)  # ,fiber_indicies=[0])#line_id=107)
    #



    #f = open("out.txt","w")
    #for x1,x2,x3 in  zip(x,v,e):
    #    s = "%f\t%f\t%f\n" % (x1,x2,x3)
    #    f.write(s)
    #f.close()

    ### todo: how to penalize for MISSING obvious lines?? cross-correlate??
    vsd = v.copy()
    penalty_cutoff = np.mean(v) + 3.0*np.std(v)
  #  vsd[vsd < penalty_cutoff] = 0.0 #vsd now has only strong (> 2x std.dev to the right) signals
   # vsd = v - np.mean(v)

    mean = np.mean(v)
    #v = v - mean

    vs = v[:-2] + v[1:-1] + v[2:]
    #vs = v[:-4] + v[1:-3] + v[2:-2] + v[3:-1] + v[4:]
    #vs = v[:-6] + v[1:-5] + v[2:-4] + v[3:-3] + v[4:-2] + v[5:-1] + v[6:]
    vs /= 3.0
    v = vs
    x = x[1:-1]

   # plt.plot(x[2:-2],vs+mean)
   # print(np.std(vs),np.std(v))
   # plt.plot(x,v)
    #plt.show()
    #exit()
    ## make the top-hat eiher 1 or -1 but not zero (so big missed signals will be big negative)?

    ## maybe have a minium area per hat to contribute? e.g. so don't gain or penalize for excessively
    #    narrow "lines" that may not be real

    s = spectrum.Spectrum()
    bob_emis = None
    bob_area = -1*np.inf
    bob_norm_area = -1*np.inf
    bob_wo = 0
    bob_hats = 0
    bob_M = None
    bob_corr= 0

    #plt.figure(figsize=(20, 5))

    x_blue = float(min(x))
    x_red = float(max(x))

    for emis in s.emission_lines:
    #todo: some lines would be redundant (just starting at a different wave length)
    #todo: could make more efficient by excluding those, at least over the overlapping wavelengths

       # if emis.w_rest != G.OII_rest:
       #     continue
        max_area = -1*np.inf
        max_norm_area = -1*np.inf
        max_hats = 0
        best_wo = 0.0
        best_M = None
        best_corr = 0
        w_rest = emis.w_rest #3727#4861#3727 #G.LyA_rest
        for wo in np.arange(max(w_rest,x_blue),x_red,2.0):
            t,hats = s.top_hat_filter(w_rest,wo,x,hat_width=12.0,negative=False)


            #only count the part that is above the mean
            #so we can deal with far-red single lines (else you'd get something for having
            #lines blue-ward, even if small and that would typically rule out high-z lyA)
            M = t*v - np.mean(v)
            M[M<0] = 0
            area = np.trapz(M, x)

            #neg_t = t[:]-1.0
            #area = area + np.trapz(vsd*neg_t) #negative area (penality for left over strong lines not included)

            norm_area = area / hats

            plot_corr(plt,emis.name, x, v, t)

            acorr = np.correlate(v,t*v,mode="same")
            corr = np.max(acorr)

            #if norm_area > max_norm_area:
            #if area > max_area:
            if corr > best_corr:
                best_corr = corr
                max_area = area
                max_hats = hats
                max_norm_area = area/hats
                best_wo = wo
                best_M = t*v
                plot_corr(plt,emis.name,x,v,t,pause=2.0)

               # print(wo,max_area,max_norm_area,hats)

        #if emis.w_rest == G.OII_rest:
        #    plot_bob(penalty_cutoff, x, v, best_M, best_wo, emis, s,name="best_oii.png")

        #if max_norm_area > bob_norm_area:
        #if max_area > bob_area:
        if best_corr > bob_corr:
            bob_corr = best_corr
            bob_emis = emis
            bob_area = max_area
            bob_norm_area = max_norm_area
            bob_wo = best_wo
            bob_hats = max_hats
            bob_M = best_M
           # plot_bob(penalty_cutoff, x, v, best_M, best_wo, emis, s)

        print("For %s (%g), w_obs = %g, z = %g, Max area: %g, Max norm area: %g, Max_hats = %d, Corr = %g"
              %(emis.name, w_rest,best_wo, best_wo/w_rest-1,max_area, max_norm_area, max_hats, best_corr))

    print("Best of the Best (BOB)\nFor %s (%g), w_obs = %g, z = %g, Max area: %g, Max norm area: %g, Max_hats = %d, Corr = %g"
          % (bob_emis.name, bob_emis.w_rest, bob_wo, bob_wo / bob_emis.w_rest - 1, bob_area, bob_norm_area, bob_hats, bob_corr))

    #so we have a best fit (ish) for z (at +/- 2AA)

    plot_bob(penalty_cutoff, x, v+mean, bob_M, bob_wo, bob_emis, s)#,name="best_fit.png")

    # plt.figure(figsize=(20,5))
    # plt.hlines(penalty_cutoff,3500,5500,colors='r')
    # plt.plot(x,v)
    # plt.plot(x,bob_M)
    # plt.ylim(ymin=-100)
    #
    # #make labels
    # z = bob_wo / bob_emis.w_rest - 1.0
    # for emis in s.emission_lines:
    #     w_obs = emis.redshift(z)
    #     if (w_obs > x[0]) and (w_obs < x[-1]):
    #         plt.text(w_obs, -10, " {" + emis.name, rotation=-90, ha='center', va='top',
    #                       fontsize=12)  # use the e color for this family
    #
    #
    #
    # plt.savefig("best_fit.png")
    #plt.show()

    #exit()

   # spectrum.signal_score(wavelengths=x, values=v, central=cw, sbr=None, show_plot=True)

    if x is not None:

        s = spectrum.Spectrum()

        #t = s.top_hat_filter(4861,best_wo,x,hat_width=50.0)
        sols = s.classify(x, v, e, cw)

        print("Flux",s.estflux)
        if s.central_eli:
            print("Cont",s.central_eli.cont)
        else:
            print("Cont unspecfied. ELI not calculated.")
        print("EW_obs",s.eqw_obs)
        if s.central_eli:
            print("SNR",s.central_eli.snr)
        else:
            print("SNR unspecfied. ELI not calculated.")
        print("P_LAE",s.p_lae)
        print("P_OII",s.p_oii)
        print("P_LAE/P_OII", s.p_lae_oii_ratio)

        s.build_full_width_spectrum(show_skylines=True, show_peaks=True, name="testsol")
        if len(sols) == 0:
            print ("No solutions")
        else:
            if sols[0].score < 3.0:
                print("Weak solution")
            if len(sols) > 1:
                if sols[0].frac_score / sols[1].frac_score < 1.5:
                    print("No clear solution")

        #full w/o solution
        s.build_full_width_spectrum( x, v, None, central_wavelength=cw, show_skylines=True, show_peaks=True,
                                name="testspec", dw=5, h=15, dh=5, zero=0.0)
    else:
        print("Error summing fibers")

#all sum
if False:

    datestr = "20170328v10"
    i = ifu.IFU(datestr, ifuslot=86)
    path = "/work/03261/polonius/maverick/karl_vol/" + datestr + "/"
    file = path + datestr + "_fib.txt"

    print("Empty sum (this can take a while)...")
    count = i.sum_empty_fibers()
    print("Fibers summed =", count)

    if count > 0:
        s = spectrum.Spectrum()
        cw = s.find_central_wavelength(i.sum_wavelengths, i.sum_values, None)
        print("Central W = ", cw)

        sols = s.classify(i.sum_wavelengths, i.sum_values, i.sum_errors,cw)

        print("Flux", s.estflux)
        if s.central_eli:
           print("Cont", s.central_eli.cont)
           print("SNR", s.central_eli.snr)
        print("EW_obs", s.eqw_obs)
        print("P_LAE", s.p_lae)
        print("P_OII", s.p_oii)
        print("P_LAE/P_OII", s.p_lae_oii_ratio)

        print ("Top value",i.sum_wavelengths[np.argmax(i.sum_values)])

        s.build_full_width_spectrum(show_skylines=True, show_peaks=True, name="emptysol")#,dw=.1)
        if len(sols) == 0:
            print ("No solutions")
        else:
            if sols[0].score < 3.0:
                print("Weak solution")
            if len(sols) > 1:
                if sols[0].frac_score / sols[1].frac_score < 1.5:
                    print("No clear solution")

    else:
        print("no empty fibers found")


