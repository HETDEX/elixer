#local only
import catalogs
from astropy.coordinates import SkyCoord
import matplotlib
#matplotlib.use('agg')
import matplotlib.pyplot as plt
import global_config as G
import numpy as np


#import cat_stack_cosmos
import cat_hsc

G.logging.basicConfig(filename="cat.log", level=G.LOG_LEVEL, filemode='w')

catlib = catalogs.CatalogLibrary()


"""
Take an RA, Dec and error (something like a few arcminutes)
Query to find the catalog (want just one)
Query the catalog for list of targets within that error
For each target, get the cutout (throw away) with the ELiXer magnitude
    record the target reported mag and the Elixer mag
    

Plot (Elixer mag as X, (Elixer mag - reported mag) as Y)

Look for trend

(repeat for other catalogs)
"""


def nano_jansky_to_mag(flux, err=None):  # ,wavelength):
    if flux <= 0.0:
        print("Cannot use negative flux (cat_base::*_janksy_to_mag()). flux =  %f" % flux)
        return 99.9, 0., 0.

    if err is None:
        return -2.5 * np.log10(flux) + 31.4, 0, 0
    else:
        cn = nano_jansky_to_cgs(flux)[0]
        mx = nano_jansky_to_cgs(flux + err)[0] - cn  # reminder, this will be negative because magnitudes
        mn = nano_jansky_to_cgs(flux - err)[0] - cn  # reminder, this will be positive because magnitudes
        return cn, mx, mn


def micro_jansky_to_mag(flux, err=None):  # ,wavelength):
    if flux <= 0.0:
        print("Cannot use negative flux (cat_base::*_janksy_to_mag()). flux =  %f" % flux)
        return 99.9, 0., 0.
    if err is None:
        return -2.5 * np.log10(flux) + 23.9, 0, 0
    else:
        cn = micro_jansky_to_mag(flux)[0]
        mx = micro_jansky_to_mag(flux + err)[0] - cn
        mn = micro_jansky_to_mag(flux - err)[0] - cn
        return cn, mx, mn


def hsc_count_to_mag(count,cutout=None,headers=None):
   # return 999.9

    #We can convert the counts into flux
    # with a keyword in the header of the imaging data;
    # FLUXMAG0=     63095734448.0194
    #
    # Because the HSC pipeline uses the zeropoint value (corresponds to 27 mag) to all filters,
    # we can convert the counts values in the R-band imaging data as follows:
    # -2.5*log(flux_R) -48.6 = -2.5*log(count_R / FLUXMAG0)
    # --> flux_R = count_R / ( 10^(30.24) )

    #note: zero point is 27 mag
    if count is not None:
    #if cutout is not None:
        #get the conversion factor, each tile is different
        try:
            fluxmag0 = float(headers[0]['FLUXMAG0'])
        except:
            fluxmag0 = 0.0
            log.error("Exception in hsc_count_to_mag",exc_info=True)
            return 99.9

        if count > 0:
            return -2.5 * np.log10(count/fluxmag0) #+ 48.6
        else:
            return 99.9  # need a better floor



ra = 215.0
dec = 50.0
arcsec = 5 *60.0 #1. * 60.

objs = catlib.get_catalog_objects(position=SkyCoord(ra,dec,unit='deg'),radius=arcsec)

print(objs[0]['dataframe'].columns)

elixer_mags = []
catalog_mags = []

total_hits = len(objs[0]['dataframe'])
count = 0

f = open("hsc_grow_out.txt","a")

for i,rec in objs[0]['dataframe'].iterrows():
    count += 1
    try:
        cuts = catlib.get_cutouts(SkyCoord(rec['RA'],rec['DEC'],unit='deg'),radius=2.5,
                              aperture=1.0,dynamic=True)
        for c in cuts:
            if (c['filter'] == 'r') and (c['mag'] is not None) and (c['mag'] < 99):
                elixer_mags.append(c['mag'])
                catalog_mags.append(rec['mag.psf'])

                f.write("(%d/%d) %f %f %f %f\n" %(count,total_hits, rec['RA'],rec['DEC'],c['mag'],rec['mag.psf']))
                f.flush()

    except Exception as e:
        print(e)

f.close()

exit()

elixer_mags = np.array(elixer_mags)
catalog_mags  = np.array(catalog_mags)
np.save("mags",(elixer_mags,catalog_mags))
#todo: maybe fit a line? also maybe kill the extreme outliers (probably something weird like masked star, etc)

import matplotlib.pyplot as plt
import numpy as np

fn = "/home/dustin/code/python/elixer/hsc_grow_out.txt"
elixer_mags, catalog_mags = np.loadtxt(fn,usecols=(3,4),unpack=True)
delta_mags = (elixer_mags-catalog_mags)
select = np.where(abs(delta_mags) <= 5)
elixer_mags = elixer_mags[select]
delta_mags = delta_mags[select]

plt.scatter(elixer_mags,delta_mags,s=0.1)

plt.title("HSC (r-band)\n1.5\" radius aperture, 7.5\"-15.0\" annulus sky")
plt.ylabel("ELiXer mag - Catalog mag")
plt.xlabel("ELiXer mag")

bin_edges = np.arange(18.0,30.0,0.5)
bin_centers = 0.5 * (bin_edges[0:-1] + bin_edges[1:])
delta_mag_values = []
delta_mag_means = np.zeros(len(bin_edges)-1)
delta_mag_sd = np.zeros(len(bin_edges)-1)


sz = len(bin_edges)-1
for i in range(sz):
    select = np.where((elixer_mags >= bin_edges[i]) & (elixer_mags < bin_edges[i+1]))
    delta_mag_values.append(delta_mags[select])
    delta_mag_means[i] = np.mean(delta_mag_values[i])
    delta_mag_sd[i] = np.std(delta_mag_values[i])

plt.errorbar(bin_centers,delta_mag_means,yerr=delta_mag_sd,xerr=0.25,fmt=".",color='r')

plt.savefig("hsc_grow_mags.png")




