'''
path = '/users/aleung/documents/research/archived/'
path = '/users/aleung/desktop/gather/mget_1227/'		### AAS poster
path = '/users/aleung/desktop/gather/mget_0323/'		### senior thesis

path = '/users/aleung/desktop/gather/mget_0422/'
path = '/users/aleung/desktop/gather/mget_0429/'
path = '/users/aleung/desktop/gather/mget_0508/'
path = '/users/aleung/desktop/gather/mget_0520/'

path = '/users/aleung/desktop/gather/mget_0603/'		### 150525_
path = '/users/aleung/desktop/gather/mget_0620/'		### 150618_

path = '/users/aleung/desktop/gather/mget_0717/'		### paper draft v3.1

path = '/users/aleung/desktop/gather/mget_0822/'		### cosmology mismatch test cases

'''

#ath = '/users/aleung/desktop/gather/mget_0818/'		### paper draft v3.9
#path = '/users/aleung/desktop/gather/mget_0824/'		### test no imaging survey
#path = '/users/aleung/desktop/gather/mget_0903/'		### paper draft v4.0
#path = '/users/aleung/desktop/gather/mget_0909/'		### paper draft v4.1
#path = '/users/aleung/desktop/gather/mget_1007/'		### paper draft v4.3




#writepath = '/users/aleung/dropbox/python/error_formula/'
#writepath = '/users/aleung/documents/python/erfGr15/'								### paper draft v4.0
#specpath = '/users/aleung/desktop/gather/spectra/'

#sudepath = '/users/aleung/documents/research/from vivi/surveydesign/'
#sudepath = '/users/aleung/documents/research/from vivi/surveydesignGr15/'	### paper draft v4.0



#fltrpath = '/users/aleung/dropbox/python/'
#rstrpath = '/users/aleung/documents/python/'


path = '/home/dustin/code/python/hetdex_LAE_OII_bayesian/gather'
sudepath ='/home/dustin/code/python/hetdex_LAE_OII_bayesian/SurveyDesignGr15'
writepath = '/home/dustin/code/python/hetdex_LAE_OII_bayesian/erfGr15/'								### paper draft v4.0
specpath = '/home/dustin/code/python/hetdex_LAE_OII_bayesian/gather/spectra/'
fltrpath = '/home/dustin/code/python/hetdex_LAE_OII_bayesian'
rstrpath = '/home/dustin/code/python/hetdex_LAE_OII_bayesian'