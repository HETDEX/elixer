import catalogs
from astropy.coordinates import SkyCoord
import matplotlib.pyplot as plt

import global_config as G

G.logging.basicConfig(filename="cat.log", level=G.LOG_LEVEL, filemode='w')

catlib = catalogs.CatalogLibrary()


#stack cosmos

#objs = catlib.get_catalog_objects(SkyCoord(150.306690, 2.286707,unit='deg'),5.)
#150.173106, 2.235351
#150.306690, 2.286707
#150.201587, 2.248422
cutouts = catlib.get_cutouts(SkyCoord(150.201587, 2.248422,unit='deg'),radius=7.0,aperture=1.5,dynamic=False)
for c in (cutouts):
    print(c['filter'],c['mag'],c['aperture'])
    plt.figure()
    plt.imshow(c['cutout'].data, origin="lower", cmap="gray_r")
    plt.show()

exit()

#EXAMPLE catalog objects

#in HSC
objs = catlib.get_catalog_objects(SkyCoord(164.2,47.2,unit='deg'),10./3600.)
print(len(objs))
print(objs[0]['name'], objs[0]['count'])
print(objs[0]['dataframe']['distance'].values)

print(objs[0]['dataframe'].columns)

for i,rec in objs[0]['dataframe'].iterrows():
    print(rec['RA'], rec['DEC'], rec['mag.psf'], rec['distance'])


exit()


#in SHELA
objs = catlib.get_catalog_objects(SkyCoord(20.0,0.0,unit='deg'),10./3600.)
print(len(objs))
print(objs[0]['name'], objs[0]['count'])
print(objs[0]['dataframe']['distance'].values)

for i in objs[0]['dataframe'].iloc[:,0].values:
    rec = objs[0]['dataframe'].loc[i-1]
    print(rec['RA'],rec['DEC'],rec['MAG_AUTO'],rec['distance'])

exit()



#example IMAGING

#in SHELA
cutouts = catlib.get_cutouts(SkyCoord(20.0,0.0,unit='deg'),60./3600.)
print(len(cutouts))

#here is an example of how to write out all 2D cutout as FITS (using the original FITS header as a basis)
import astropy.io.fits as fits

for i in range(len(cutouts)):
    co = cutouts[i]['cutout']
    hdu = fits.PrimaryHDU(co.data) #essentially empty header
    hdu.header.update(co.wcs.to_header()) #insert the cutout's WCS
    hdu.writeto('test_cutout_%d.fits' %i, overwrite=True)

exit()

#in HSC
cutouts = catlib.get_cutouts(SkyCoord(164.2,47.2,unit='deg'),10./3600.)
print(len(cutouts))



#coord = SkyCoord(150.025406,2.0876,unit='deg')
print(cutouts[3]['hdu'][0].header['MAGZERO'])
r = [c for c in cutouts if c['filter'] == 'r']
print(r[0]['hdu'][0].header['MAGZERO'])

print(r[0]['path'])

plt.figure()
plt.imshow(cutouts[3]['cutout'].data, origin="lower", cmap="gray_r")
plt.show()


#note: cutouts might be empty ... usual case is that there are no overlapping catalogs
#or there are holes in the catalog footprint where a cutout cannot be made
coord = SkyCoord(211.9,48.7,unit='deg')
cats = catlib.find_catalogs(coord,10./3600)
cutouts = catlib.get_cutouts(coord,10./3600.,catalogs=cats)
print(len(cutouts))






