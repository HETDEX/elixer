import global_config as G
import numpy as np
import tables

log = G.Global_Logger('knl')
log.setlevel(G.logging.DEBUG)


G.logging.basicConfig(filename=G.LOG_FILENAME, level=G.LOG_LEVEL, filemode='w')

log.debug("starting")
log.debug("hdf5 test ...")
with tables.open_file(G.HDF5_DETECT_FN, mode="r") as h5:
    dtb = h5.root.Detections
    ra = 150.123
    dec = 2.121

    error = 120.0/3600.
    ra1 = ra - error
    ra2 = ra + error
    dec1 = dec - error
    dec2 = dec + error

    rows = dtb.read_where("(ra > ra1) & (ra < ra2) & (dec > dec1) & (dec < dec2)")

    if (rows is not None) and (rows.size > 0):
        detectids = rows['detectid']
        msg = "%d detection records found +/- %g\" from %f, %f" % (rows.size, error * 3600., ra, dec)
        log.info(msg)
        print(msg)
    else:
        msg = "0 detection records found +/- %g\" from %f, %f" % (error * 3600., ra, dec)
        log.info(msg)
        print(msg)
log.debug("hdf5 test end ...")

for i in range(10000):
    log.debug("%f " %np.random.random())

log.debug("done")

exit(0)
