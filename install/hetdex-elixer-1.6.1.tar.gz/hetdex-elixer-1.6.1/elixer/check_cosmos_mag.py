#local only
import catalogs
from astropy.coordinates import SkyCoord
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import global_config as G
import numpy as np


import cat_stack_cosmos

G.logging.basicConfig(filename="cat.log", level=G.LOG_LEVEL, filemode='w')

catlib = catalogs.CatalogLibrary()


"""
Take an RA, Dec and error (something like a few arcminutes)
Query to find the catalog (want just one)
Query the catalog for list of targets within that error
For each target, get the cutout (throw away) with the ELiXer magnitude
    record the target reported mag and the Elixer mag
    

Plot (Elixer mag as X, (Elixer mag - reported mag) as Y)

Look for trend

(repeat for other catalogs)
"""


def nano_jansky_to_mag(flux, err=None):  # ,wavelength):
    if flux <= 0.0:
        print("Cannot use negative flux (cat_base::*_janksy_to_mag()). flux =  %f" % flux)
        return 99.9, 0., 0.

    if err is None:
        return -2.5 * np.log10(flux) + 31.4, 0, 0
    else:
        cn = nano_jansky_to_cgs(flux)[0]
        mx = nano_jansky_to_cgs(flux + err)[0] - cn  # reminder, this will be negative because magnitudes
        mn = nano_jansky_to_cgs(flux - err)[0] - cn  # reminder, this will be positive because magnitudes
        return cn, mx, mn


def micro_jansky_to_mag(flux, err=None):  # ,wavelength):
    if flux <= 0.0:
        print("Cannot use negative flux (cat_base::*_janksy_to_mag()). flux =  %f" % flux)
        return 99.9, 0., 0.
    if err is None:
        return -2.5 * np.log10(flux) + 23.9, 0, 0
    else:
        cn = micro_jansky_to_mag(flux)[0]
        mx = micro_jansky_to_mag(flux + err)[0] - cn
        mn = micro_jansky_to_mag(flux - err)[0] - cn
        return cn, mx, mn


#STACK COSMOS
def get_cosmos_filter_flux(df):  # right now, only g-band catalog

    filter_fl = None
    filter_fl_err = None
    mag = None
    mag_bright = None
    mag_faint = None
    filter_str = None
    try:

        filter_str = 'r'
        dfx = df

        filter_fl = dfx['FLUX_AUTO']  # in micro-jansky or 1e-29  erg s^-1 cm^-2 Hz^-2
        filter_fl_err = dfx['FLUXERR_AUTO']

        mag = dfx['MAG_AUTO']
        mag_faint = dfx['MAGERR_AUTO']
        mag_bright = -1 * mag_faint

        # something is way wrong with the MAG_AUTO
        mag, mag_bright, mag_faint = micro_jansky_to_mag(filter_fl, filter_fl_err)

    except:  # not the EGS df, try the CFHTLS
        pass

    return filter_fl, filter_fl_err, mag, mag_bright, mag_faint, filter_str

ra = 150.025375
dec = 2.087994
arcsec = 5* 60.0 #1. * 60.

objs = catlib.get_catalog_objects(position=SkyCoord(ra,dec,unit='deg'),radius=arcsec)


elixer_mags = []
catalog_mags = []

total_hits = len(objs[0]['dataframe'])
count = 0

f = open("out.txt","a")

for i,rec in objs[0]['dataframe'].iterrows():
    count += 1
    try:
        cuts = catlib.get_cutouts(SkyCoord(rec['RA'],rec['DEC'],unit='deg'),radius=2.5,
                              aperture=G.FIXED_MAG_APERTURE,dynamic=False)
        for c in cuts:
            if (c['filter'] == 'r') and (c['mag'] is not None) and (c['mag'] < 99):
                filter_fl, filter_fl_err, filter_mag, filter_mag_bright, filter_mag_faint, filter_str = get_cosmos_filter_flux(rec)
                print("%d of %d)" %(count,total_hits), c['filter'],c['aperture'],  c['mag'], filter_mag, filter_mag_bright, filter_mag_faint)
                elixer_mags.append(c['mag'])
                catalog_mags.append(filter_mag)

                f.write("(%d/%d) %f %f %f %f %f %f\n" %(count,total_hits, rec['RA'],rec['DEC'],c['mag'],filter_mag,filter_mag_bright,filter_mag_faint))
                f.flush()

    except Exception as e:
        print(e)

f.close()

elixer_mags = np.array(elixer_mags)
catalog_mags  = np.array(catalog_mags)
np.save("mags",(elixer_mags,catalog_mags))
#todo: maybe fit a line? also maybe kill the extreme outliers (probably something weird like masked star, etc)


import matplotlib.pyplot as plt
import numpy as np

fn = "/home/dustin/code/python/elixer/check_mag/cosmos_biweight_out.txt"
elixer_mags, catalog_mags = np.loadtxt(fn,usecols=(3,4),unpack=True)
delta_mags = (elixer_mags-catalog_mags)
select = np.where(abs(delta_mags) <= 5)
select = np.where(abs(delta_mags) <= 5)
elixer_mags = elixer_mags[select]
delta_mags = delta_mags[select]

plt.scatter(elixer_mags,delta_mags,s=0.1)

plt.title("Cosmos (Isak) (r-band)\n1.5\" radius aperture, 7.5\"-15.0\" annulus sky")
plt.ylabel("ELiXer mag - Catalog mag")
plt.xlabel("ELiXer mag")


bin_edges = np.arange(18.0,30.0,0.5)
bin_centers = 0.5 * (bin_edges[0:-1] + bin_edges[1:])
delta_mag_values = []
delta_mag_means = np.zeros(len(bin_edges)-1)
delta_mag_sd = np.zeros(len(bin_edges)-1)


sz = len(bin_edges)-1
for i in range(sz):
    select = np.where((elixer_mags >= bin_edges[i]) & (elixer_mags < bin_edges[i+1]))
    delta_mag_values.append(delta_mags[select])
    delta_mag_means[i] = np.mean(delta_mag_values[i])
    delta_mag_sd[i] = np.std(delta_mag_values[i])

plt.errorbar(bin_centers,delta_mag_means,yerr=delta_mag_sd,xerr=0.25,fmt=".",color='r')


plt.savefig("cosmos_mags.png")





