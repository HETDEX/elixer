import tarfile as tar
import os
from astropy.io import fits as pyfits



#name = '/home/dustin/code/python/tartest/test.tar'
name = '/home/dustin/code/python/elixer/tar/virus0000001.tar'

if False:
    if os.path.exists(name):

        try:
            if tar.is_tarfile(name):
                tarfile = tar.open(name=name)
        except:
            print("could not open tarfile")
            tarfile = None


        if tarfile is None:
            exit(0)


        fqdn = tarfile.getnames() #list of all conents (as full paths) includes directories

        txt = tarfile.extractfile("test/dirname2/file2.txt")

        tarfits = tarfile.extractfile("test/dirname1/multi_304_034_003_RU.fits")
        f = pyfits.open(tarfits)
        f[0].header
        f.close()

        tarfile.close()



