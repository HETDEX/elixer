import numpy as np
import astropy.io.fits as fits
from astropy.coordinates import SkyCoord
from astropy.nddata import Cutout2D
from astropy.wcs import WCS
from time import sleep
import sys


import traceback
import guppy
hpy = guppy.hpy()

import psutil

MB = 2**20
path = "/work/03229/iwold/maverick/stackCOSMOS/nano/COSMOS_g_sci.fits"
ra = 149.990189
dec = 2.157108
#window = 5.0
pix_window = 50  # now in pixels
hdulist = fits.open(path)
wcs = WCS(path)

position = SkyCoord(ra, dec, unit="deg", frame='icrs')

id = np.random.random_integers(1e9,9e9)
a = []
dim = int(5e3)
try:
    print("bulk allocation approx (%d) MB" %( int((dim**2)*8/MB) ))
    bulk = np.zeros((dim,dim)) #float64 so 8 bytes per ... so ~ 190MB at 5000x5000x8
    print("bulk allocation approx (%d) MB (success)" %( int((dim**2)*8/MB) ))
except Exception as e:
    print("[%d] exception follows (bulk)" % id)
    traceback.print_exc()
    print(str(e))


for i in range(1000):
    print("[%d] (%d) before %f (%f) " %(id, i, float(hpy.heap().size)/MB, float(psutil.virtual_memory().total)/MB))

    sleep(0.1)
    try:
        cutout = Cutout2D(hdulist[0].data, position, (pix_window, pix_window), wcs=wcs, copy=True)
        print("Cutout size = %f bytes" % sys.getsizeof(cutout))
        print("Cutout.data size = %f bytes" % sys.getsizeof(cutout.data))
        #cutout = np.zeros((pix_window,pix_window)) #similar without the extra cutout header info
        a.append(cutout)
    except Exception as e:
        print("[%d] exception follows " % id)
        sleep(0.1)
        traceback.print_exc()

    print("[%d] (%d) after %f (%f)" % (id, i, float(hpy.heap().size) / MB, float(psutil.virtual_memory().total)/MB))
