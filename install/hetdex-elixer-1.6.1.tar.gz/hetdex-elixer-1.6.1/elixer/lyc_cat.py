"""
Read elixer cat.txt and fib.txt files and combine with HDF5 selection to make clean LAE catalog
for stacking spectra in serach of Lyman Continuum
"""

import numpy as np

CALFIB_WAVEGRID = np.arange(3480,5552,2) #3480 - 5550

class Neighbor:
    #a catalog neighbor
    def __init__(self):
        self.ra = None
        self.dec = None
        self.mag = None
        self.filter = None #filter for the magnitude
        self.distance = None #distance in arcsecs
        self.plae_poii = None #P(LAE)/P(OII)


class Detection:
    #represents a single detection (may or may not be an acceptable LAE
    def __init__(self):


        self.detectid = None #i.e. 1000000xxx
        self.detectname = None #i.e. 20180123v009_137
        self.ra = None
        self.dec = None
        self.w = None #observed wavelength

        self.z = None #assumes LyA

        self.ew_obs = None
        self.ew_rest = None #assuming LyA z
        self.line_flux = None

        self.sigma = None
        self.chi2 = None
        self.continuum = None

        self.plae_poii = None #hetdex only data

        self.central_fiber_spectrum = [] #i.e. the calfib (rectified and calibrated spectrum)
        self.central_fiber_spectrum_err = [] #i.e. calfibe

        self.neighbors = [] #empty list (of Neighbors)


    #?? include best (central) fiber here?


    @property
    def num_neighbors(self):
        try:
            return len(self.neighbors)
        except:
            return -1





def read_elixer_catalogs(fibfn,catfn):
    """
    read the _fib.txt and _cat.txt catalogs
    create Detections for each (combining across and within catalogs as needed)

    :return: list of Detections
    """

    detections = []

    #should be one line per detection in fib.txt
    #at least one line but may be more in cat.txt

    #read fib.txt first and build out list of detections
    with open(fibfn,"r") as f:
        for line in f:
            if f[0] == '#':
                continue

            if len(line) < 100:
                continue

            toks = line.split() #white space split

            if len(toks) < 29: #must be at least 29 for _fib.txt
                continue

            d = Detection()

            d.detectid = toks[1]
            d.ra = toks[3]
            d.dec = toks[4]
            d.w = toks[5]
            d.sigma = toks[6]
            d.chi2 = toks[7]
            d.line_flux = toks[10]
            d.continuum = toks[12]

            d.plae_poii = toks[14]

            d.detectname


    #then read cat.txt and match up to existing entry in detections list




def save_catalog(fn):
    """
    Write out (pickle?) the list of detections.

    Could be refined list (that accounts for HDF5 subselection)

    :param fn:
    :return:
    """
